<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);
  exit;
}

// Telegram credentials (hidden on server)
define('BOT_TOKEN', '8075916360:AAFb0tLQJXgIc4GgfXF12gyk-nxUd3WXzLM');
define('CHAT_ID', '-5280601304');

$method = $_REQUEST['method'] ?? '';
if (!$method) {
    echo json_encode(['ok' => false, 'error' => 'No method specified']);
    exit;
}

$url = 'https://api.telegram.org/bot' . BOT_TOKEN . '/' . $method;

// Check if request is multipart/form-data (like sendPhoto)
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';

if (strpos($contentType, 'multipart/form-data') !== false) {
    // Process form data with file
    $postData = $_POST;
    // Overwrite the chat_id so clients can't change it
    $postData['chat_id'] = CHAT_ID;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    
    if (isset($_FILES['photo'])) {
        $cfile = new CURLFile($_FILES['photo']['tmp_name'], $_FILES['photo']['type'], $_FILES['photo']['name']);
        $postData['photo'] = $cfile;
    }
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    echo $result;
    exit;
} else {
    // Process JSON body for sendMessage, getUpdates, etc.
    $input = file_get_contents('php://input');
    
    if ($input) {
        $data = json_decode($input, true) ?: [];
    } else {
        $data = $_GET; // Support GET parameters like offset
    }
    
    // Always enforce the chat_id if not getUpdates
    if ($method !== 'getUpdates') {
        $data['chat_id'] = CHAT_ID;
    }
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    if (!empty($data) || $_SERVER['REQUEST_METHOD'] === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    
    $result = curl_exec($ch);
    curl_close($ch);
    echo $result;
}
