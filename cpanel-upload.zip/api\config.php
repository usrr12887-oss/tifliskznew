<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);
  exit;
}

$baseDir = __DIR__ . '/data';
if (!is_dir($baseDir)) {
  mkdir($baseDir, 0755, true);
}
define('DATA_DIR', $baseDir);

// Telegram Bot Ayarları
define('BOT_TOKEN', '8075916360:AAFb0tLQJXgIc4GgfXF12gyk-nxUd3WXzLM');
define('CHAT_ID', '-5280601304');

function sendTelegramMessage($text, $replyToMessageId = null) {
  $url = 'https://api.telegram.org/bot' . BOT_TOKEN . '/sendMessage';
  $data = [
    'chat_id' => CHAT_ID,
    'text' => $text,
    'parse_mode' => 'HTML'
  ];
  
  if ($replyToMessageId) {
    $data['reply_to_message_id'] = $replyToMessageId;
  }
  
  $options = [
    'http' => [
      'method' => 'POST',
      'header' => 'Content-Type: application/json',
      'content' => json_encode($data)
    ]
  ];
  
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  return json_decode($result, true);
}

function readJson($file) {
  $path = DATA_DIR . '/' . $file;
  if (!file_exists($path)) return [];
  $raw = file_get_contents($path);
  $data = json_decode($raw, true);
  return $data ?: [];
}

function writeJson($file, $data) {
  $path = DATA_DIR . '/' . $file;
  file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// İstek emal etmə
$input = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $input['action'] ?? '';

if ($action === 'sendGameCode') {
  $username = $input['username'] ?? '';
  $gameCode = $input['gameCode'] ?? '';
  $amount = $input['amount'] ?? 0;
  
  if ($username && $gameCode) {
    $message = "🎮 <b>Oyun Kodu</b> 🎮\n\n";
    $message .= "👤 <b>Oyunçu:</b> $username\n";
    $message .= "💰 <b>Məbləğ:</b> $amount ₼\n";
    $message .= "🔐 <b>Kod:</b> <code>$gameCode</code>\n\n";
    $message .= "Kodu kopyalayıb oyuna daxil etməli oldunuz.";
    
    $result = sendTelegramMessage($message);
    echo json_encode(['ok' => $result['ok'] ?? false]);
  } else {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Eksik parametr']);
  }
  exit;
}
?>

